#include<stdio.h>
#include<math.h>
#include<string.h>
#include<time.h>
#include<stdlib.h>
#include<limits.h>
#include<unistd.h>

#define SMALLSLEEP 1
#define MIDSLEEP 2
#define BIGSLEEP 3
#define STARTMONEY 15000

typedef struct card
{
  char valueName[20];
  char suit[20];
  int value;
} card;

//I realized a little too late that we didn't really need three differenct structs here :/
typedef struct pikerDeck
{
  card cards[40];
} pikerDeck;

typedef struct blackholeJackDeck
{
  card cards[40];
} blackholeJackDeck;

typedef struct plutoBancoDeck
{
  card cards[40];
} plutoBancoDeck;


//Blackhole Jack-Exclusive Functions
void blackholeJack(int * totalMoney);
int hitOrStand(void);
blackholeJackDeck makeBlackholeJackDeck();
void playBlackholeJackAgain(int * totalMoney);
int getBlackholeJackBet(int * totalMoney);

//Piker-Exclusive Functions
void Piker(int * totalMoney);
int initializePiker(int * totalMoney);
pikerDeck makeDeck();
void printTable(card * Table, int * cardsOnTable);

//Pluto Banco-Exclusive Functions
void plutoBanco(int * totalMoney);
plutoBancoDeck makePlutoBancoDeck();
int getPlutoBancoBet(int * totalMoney, int * whatToBetOn);
void playPlutoBancoAgain(int * totalMoney);
void dealerDraw(card *dealerHand, int dealerTotal, plutoBancoDeck deck, int currentCard, int dealerHandSize);

//microblazers and GringleBall
void microblazers(int *moneytotal);
int getGringleBallBet(int *totalMoney);

void GringleBall(int * totalMoney);

//Functions that are not exclusive to one game
void printCard(card cardToPrint);
void printHand(card hand[], int handSize);
void printRoll(int roll);
int toOctal(int roll);
int toDecimal(int set);
void moneyCount(int total, int *glork, int *nebo, int *schlork, int *blizzer, int *porj, int *expo);
void printCardsArt(card *hand, int size);
int main(void);

//plotline
void start();

void max();
void min();
void security();
void run();
void escape();
void vacuum();
void capture();
void fight();
void credits();
void leave(int *totalMoney);
void owe();
void settled();
