#include "spaceCasino.h"
//"Bleeboes", "Gleeboes", "Schleeboes", "Fleeboes"};
void printCardsArt(card *hand, int size) {
  //int size2 = size;
  int test = 0;
  printf("\n");
  if (size == -1) {
    printf("____________________\n|                  |\n|                  |\n|                  |\n|                  |\n|                  |\n|                  |\n|                  |\n|                  |\n|                  |\n|                  |\n|                  |\n|                  |\n--------------------\n\n");
    size = 2;
    test++;
    usleep(500000);
  }
  for (int x = 0; x < size; x++) {
    if (test == 1) x++;
    usleep(500000);
    printf("____________________\n");
    while (strcmp(hand[x].valueName, "Glizbo") == 0) {
      if (strcmp(hand[x].suit, "Bleeboes") == 0) {
        printf("|              ____|\n");
        printf("|  %d           |  ||\n", hand[x].value);
        printf("|              ----|\n");
        printf("|      ///-\\\\\\     |\n|      |^   ^|     |\n|      |0   0|     |\n|      |  ~  |     |\n|       \\ o /      |\n|        | |       |\n");
        printf("|                  |\n");
        printf("|               %d  |\n", hand[x].value);
        printf("|                  |\n");
        printf("--------------------\n\n"); 
        usleep(500000);
        break;
      } else if (strcmp(hand[x].suit, "Gleeboes") == 0) {
        printf("|                /\\|\n");
        printf("|  %d             \\/|\n", hand[x].value);
        printf("|                  |\n");
        printf("|      ///-\\\\\\     |\n|      |^   ^|     |\n|      |0   0|     |\n|      |  ~  |     |\n|       \\ o /      |\n|        | |       |\n");
        printf("|                  |\n");
        printf("|               %d  |\n", hand[x].value);
        printf("|                  |\n");
        printf("--------------------\n\n"); 
        usleep(500000);
        break;
      } else if (strcmp(hand[x].suit, "Schleeboes") == 0) {
        printf("|               __ |\n");
        printf("|  %d           (  )|\n", hand[x].value);
        printf("|               -- |\n");
        printf("|      ///-\\\\\\     |\n|      |^   ^|     |\n|      |0   0|     |\n|      |  ~  |     |\n|       \\ o /      |\n|        | |       |\n");
        printf("|                  |\n");
        printf("|               %d  |\n", hand[x].value);
        printf("|                  |\n");
        printf("--------------------\n\n"); 
        usleep(500000);
        break;
      } else  {
        printf("|                  |\n");
        printf("|  %d             @ |\n", hand[x].value);
        printf("|                  |\n");
        printf("|      ///-\\\\\\     |\n|      |^   ^|     |\n|      |0   0|     |\n|      |  ~  |     |\n|       \\ o /      |\n|        | |       |\n");
        printf("|                  |\n");
        printf("|               %d  |\n", hand[x].value);
        printf("|                  |\n");
        printf("--------------------\n\n"); 
        usleep(500000);
        break;
      } 
    } 
    while (strcmp(hand[x].valueName, "Schnarlack") == 0) {
      if (strcmp(hand[x].suit, "Bleeboes") == 0) {
        printf("|              ____|\n");
        printf("|  %d           |  ||\n", hand[x].value);
        printf("|              ----|\n");
        printf("|       (()))      |\n|      ((\"\"\"))     |\n|      (|*_*|)     |\n|       : = :      |\n|        ) (       |\n");
        printf("|                  |\n");
        printf("|                  |\n");
        printf("|               %d  |\n", hand[x].value);
        printf("|                  |\n");
        printf("--------------------\n\n");
        usleep(500000);
        break;
      } else if (strcmp(hand[x].suit, "Gleeboes") == 0) {
        printf("|                /\\|\n");
        printf("|  %d             \\/|\n", hand[x].value);
        printf("|                  |\n");
        printf("|       (()))      |\n|      ((\"\"\"))     |\n|      (|*_*|)     |\n|       : = :      |\n|        ) (       |\n");
        printf("|                  |\n");
        printf("|                  |\n");
        printf("|               %d  |\n", hand[x].value);
        printf("|                  |\n");
        printf("--------------------\n\n");
        usleep(500000);
        break;
      } else if (strcmp(hand[x].suit, "Schleeboes") == 0) {
        printf("|               __ |\n");
        printf("|  %d           (  )|\n", hand[x].value);
        printf("|               -- |\n");
        printf("|       (()))      |\n|      ((\"\"\"))     |\n|      (|*_*|)     |\n|       : = :      |\n|        ) (       |\n");
        printf("|                  |\n");
        printf("|                  |\n");
        printf("|               %d  |\n", hand[x].value);
        printf("|                  |\n");
        printf("--------------------\n\n");
        usleep(500000);
        break;
      } else {
        printf("|                  |\n");
        printf("|  %d             @ |\n", hand[x].value);
        printf("|                  |\n");
        printf("|       (()))      |\n|      ((\"\"\"))     |\n|      (|*_*|)     |\n|       : = :      |\n|        ) (       |\n");
        printf("|                  |\n");
        printf("|                  |\n");
        printf("|               %d  |\n", hand[x].value);
        printf("|                  |\n");
        printf("--------------------\n\n");
        usleep(500000);
        break;
      }
    }
    while (strcmp(hand[x].valueName, "Glizbo") != 0 && strcmp(hand[x].valueName, "Schnarlack") != 0) {
      if (strcmp(hand[x].suit, "Bleeboes") == 0) {
        printf("|              ____|\n");
        printf("|  %d           |  ||\n", hand[x].value);
        printf("|              ----|\n");
        printf("|     ________     |\n|     |      |     |\n|     |      |     |\n|     |      |     |\n|     |      |     |\n|     --------     |\n");
        printf("|                  |\n");
        printf("|               %d  |\n", hand[x].value);
        printf("|                  |\n");
        printf("--------------------\n\n"); 
        usleep(500000);
        break;
      } else if (strcmp(hand[x].suit, "Gleeboes") == 0) {
        printf("|                /\\|\n");
        printf("|  %d             \\/|\n", hand[x].value);
        printf("|        /\\        |\n");
        printf("|       /  \\       |\n|      /    \\      |\n|     /      \\     |\n|     \\      /     |\n|      \\    /      |\n|       \\  /       |\n");
        printf("|        \\/        |\n");
        printf("|               %d  |\n", hand[x].value);
        printf("|                  |\n");
        printf("--------------------\n\n"); 
        usleep(500000);
        break;
      } else if (strcmp(hand[x].suit, "Schleeboes") == 0) {
        printf("|               __ |\n");
        printf("|  %d           (  )|\n", hand[x].value);
        printf("|               -- |\n");
        printf("|      ______      |\n|     /      \\     |\n|    |        |    |\n|    |        |    |\n|     \\      /     |\n|      ------      |\n");
        printf("|                  |\n");
        printf("|               %d  |\n", hand[x].value);
        printf("|                  |\n");
        printf("--------------------\n\n"); 
        usleep(500000);        
        break;
      } else  {
        printf("|                  |\n");
        printf("|  %d             @ |\n", hand[x].value);
        printf("|                  |\n");
        printf("|       ____       |\n|      / /\\ \\      |\n|     | |--| |     |\n|     | |  | |     |\n|      \\  __/      |\n|       ----       |\n");
        printf("|                  |\n");
        printf("|               %d  |\n", hand[x].value);
        printf("|                  |\n");
        printf("--------------------\n\n"); 
        usleep(500000);
        break;
      } 
    }
  }
  test = 0;
}