#include "spaceCasino.h"

void start()
{
  printf("You wake on a rough carpeted floor. You don't remember anything in your surroundings. It's incredibly bright, and you find it hard to open your eyes");
  //sleep(2);
  printf("You notice a man standing above you, and he seems to be smiling. \"Hello friend, welcome to the Space Casino! I can see that your a little, *ahem*, strapped for cash, so I'll lend you a few glork to play with. Enjoy the bounty of games!\"\n");
  //sleep(10);
}

void max() 
{
  sleep(MIDSLEEP);
  printf("The dealer looks at you and says that they have never had anyone win so big. You feel excited, maybe you have enough to get out of this place. \n");
  sleep(MIDSLEEP);
  printf("They squint at you, making a face that makes you feel like you've done somthing horribly wrong. The excitement that you felt only moments before turns to dread. \n");
  sleep(MIDSLEEP);
  printf("They reach into their pocket and press something. \nWithin moments you notice the security guards that had been wandering around before all start to converge on your location. \n");
  sleep(MIDSLEEP);
  printf("One comes up beside you and grabs your arm. \n\"What are you doing! I haven't done anything wrong!\"\n The dealer levels you with a cold stare.\n\"The boss does not stand for cheaters.\" \n");
  sleep(MIDSLEEP);
  printf("They switch their gaze to the guard holding you, \"Take them away boys.\"");
  printf("What do you want to do?\n1. Run\n2. Fight\n");

  char scan[100];
  int scanValue = 0;

  while (scanValue != 1 && scanValue != 2)
  {
    scanf(" %s", scan);
    scanValue = atoi(scan);

    if (scanValue == 1)
    {
      run();
    }
    else if (scanValue == 2)
    {
      fight();
    }
  }
}

void min()
{
  printf("'This can't be!', you think as you lose the kind man's lent fortune. You get a sinking feeling in your stomach, as you know he'll be looking to collect, and soon. \n");
  sleep(MIDSLEEP);
  printf("A man grabs you from out of your chair and places you on your feet. He stares at you from behind a dark pair of sunglasses and says, 'It looks like you've lost the entirety of your loan'\n");
  sleep(MIDSLEEP);
  printf("What do you want to do?\n1. Run\n2. Fight\n");

  char scan[100];
  int scanValue = 0;

  while (scanValue != 1 && scanValue != 2)
  {
    scanf(" %s", scan);
    scanValue = atoi(scan);

    if (scanValue == 1)
    {
      run();
    }
    else if (scanValue == 2)
    {
      fight();
    }
  }
}
void run()
{
  printf("Your able to squeeze past the security officers, and they start on your tail. However, it becomes imediately apparent that you're much faster than them. \n");
  sleep(MIDSLEEP);
  printf("At this point, the only reasonable place to run to is the exit. From what you can tell, there's two paths that'll get you there: through the floor, and though the kitchen.\n");
  sleep(MIDSLEEP);
  printf("Where do you want to go?\n1. Through the floor\n2. Through the Kitchen\n\n");
  
  char scan[100];
  int scanValue = 0;

  while (scanValue != 1 && scanValue != 2)
  {
    scanf(" %s", scan);
    scanValue = atoi(scan);

    if (scanValue == 1)
    {
      escape();
    }
    else if (scanValue == 2)
    {
      capture();
    }
  }
}
void escape()
{
  printf("Yes! Running through the crowded casino floor was the right choice to make. \n");
  sleep(MIDSLEEP);
  printf("As you duck in between people, tables, and machines, you maintain enough speed to keep a lead on your potential assailants.\n");
  sleep(MIDSLEEP);
  printf(" Before you know it, you're face to face with the front doors of the Space Casino\n");
  vacuum();
}
void vacuum() {
  printf("The doors slide open to reveal a small entryway. You rush in, wanting to get out of the casino as quickly as possible.\n");
  sleep(MIDSLEEP);
  printf("As the doors slide shut behind you you feintly hear a voice saying, \"Air lock sealed.\"\n");
  sleep(MIDSLEEP);
  printf("Before you can ponder these words the doors in front of you slide open to reveal vast nothingness. ");
  sleep(MIDSLEEP);
  printf("You're immeditly stuck out into the vaccume of space. ");
  sleep(MIDSLEEP);
  printf("In your last seconds of life all you can feel is the opressive cold and the burning in your lungs. ");
  sleep(BIGSLEEP);
  printf("As the edges of your vision fade to black you spin around and see The Space Casino, lit up in neon lights. ");
  sleep(BIGSLEEP);
  printf("It's the last thing you ever see.\n");
  credits();
}
void capture()
{
  printf("As you duck into the kitchen, you realize your mistake. \n");
  sleep(MIDSLEEP);
  printf("Despite your best efforts to be quick, it's just too crowded to make an easy escape. You run into a metal shelf, toppling it over on top of yourself, and sending pans and pots flying across the room. \n");
  sleep(MIDSLEEP);
  printf("Security is able to catch up to you, and they take you to the 'back room'. \n");
  sleep(MIDSLEEP);
  printf("You get the feeling that you'll never escape. The End.\n");
  credits();
}
void fight()
{
  printf("What? Did you think that you would be able to take down armed security officers? Nope, and you paid the ultimate price for it. The End.\n\n");
  credits();
}

void leave(int *totalMoney) 
{
  printf("The same man from when you woke up in this place approaches you from out of nowhere.\n");
  sleep(MIDSLEEP);
  printf("\"Leaving so soon my friend?\"\nHe slaps you on the back, nearly knocking you over.\n");
  if (*totalMoney >= STARTMONEY) {
    settled();
  }
  if (*totalMoney < STARTMONEY) owe();
}
void owe() {
  //int choice = 0;
  
  printf("\"I think it's about time for me to head out,\" your hands shake slightly from the nerves. \n");
  sleep(MIDSLEEP);
  printf("You don't have enough money to pay him back for what he lent you, and you're hoping he isn't going to ask for it back.\n");
  sleep(MIDSLEEP);
  printf("\"Now hold on just a second,\" He grabs your shoulder tightly and your stomach drops. Of course he wants his money back, but you have no way of paying him. \"I seem to remember that I lent you some glorks when you got here, are you planning on skipping out while you still owe me?\"\n");
  sleep(MIDSLEEP);
  printf("What do you want to do?\n1. Run\n2. Fight\n");

  char scan[100];
  int scanValue = 0;

  while (scanValue != 1 && scanValue != 2)
  {
    scanf(" %s", scan);
    scanValue = atoi(scan);

    if (scanValue == 1)
    {
      run();
    }
    else if (scanValue == 2)
    {
      fight();
    }
  }
}
void settled() {
  printf("\"I think it's about time for me to head out, and I have that money that you loned me, thanks for that\" you say. \n");
  sleep(MIDSLEEP);
  printf("The man is smiling but there is something sinister about it. You want to get away from him as quickly as possible.\n");
  sleep(MIDSLEEP);
  printf("\"Well I hope to see you here again sometime, you can head right out of that door\"\nHe points to a door at the front of the casino. \n");
  sleep(MIDSLEEP);
  printf("You walk toward it relieved to finally get out of this place\n");
  vacuum();
}

void credits(void)
{
  sleep(2);
  printf("Programmers: Jacob Hough, Abby Hynes, and Alex Wears\n\n");
  sleep(2);
  printf("Story: Jacob Hough, Abby Hynes, and Alex Wears\n\n");
  sleep(2);
  printf("ASCII Art: Abby Hynes Exclusively\n\n");
  sleep(2);
  printf("Meals: Provided by Tigerhacks\n\n");
  sleep(2);
  printf("This has been... The Space Casino\n");
  exit(0);
}
