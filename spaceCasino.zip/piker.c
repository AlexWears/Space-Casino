#include "spaceCasino.h"

void PlayUser(int * UserBet, int * PreviousBet, int * AIBet, card * Table, card * UserHand, int * cardsOnTable, int * totalMoney, int * totalBet, int counter, int * bettingPool);
void PlayAI(int whichAI, card * AIHand, card * Table, int * UserBet, int * PreviousBet, int * totalBet, int * folded, int roundcounter, int OnTable, int * bettingPool, int * AIBet);
void PlayTable(card * OnTable, pikerDeck * Deck, int * currentCard, int i);
void Deal(pikerDeck * Deck, int * currentCard, card * UserHand, card * AIHand, int players);
int PlayerMove();
int AIMove();
int DeckValue(card * Table, card * Hand, int OnTable);
card * DeckSort(card * deck, int number);
int RoundCheck(int * AIBet, int * UserBet, int players, int * Folded);
void PikerRules(void);

void Piker(int * totalMoney)
{
  if(initializePiker(totalMoney) == 0)
  {
    return;
  }
  int players = 0;

  PikerRules();

  while(players < 1 || players > 3)
  {
    printf("How many opponents would you like?\n");
    printf("(At Least 1, at most 3)\n");
    scanf("%d", &players);
    if((players<1) || (players>3)) 
    {
      printf("Sorry. House rules.\n\n");
    }
  }

  pikerDeck Deck = makeDeck();

  for (int j = 0; j < 2; j++)
  {
    for (int i = 0; i < 40; i++)
    {
      card cardSaver = Deck.cards[i];
      int randomNumber = rand()%40;
      
      Deck.cards[i] = Deck.cards[randomNumber];
      Deck.cards[randomNumber] = cardSaver; 
    }
  }
  
  card OnTable[3];
  int currentCardOG = 0;
  int * currentCard = &currentCardOG;
  int UserBetOG = 0;
  int * UserBet = &UserBetOG;
  int PreviousBetOG = 0;
  int * PreviousBet = &PreviousBetOG;
  int AIBet[3] = {0};
  int AIMoney[3];
  card UserHand[2];
  card AIHand[6];
  int Folded[3];
  int RoundCounter = 0;
  int totalBetOG = 0;
  int * totalBet = &totalBetOG;
  int bettingPoolOG = 0;
  int * bettingPool = &bettingPoolOG;
  
  //printf("before deal\n");

  Deal(&Deck, currentCard, UserHand, AIHand, players);

  for(int j = 0; j < players; j++)
  {
    AIMoney[j] = *totalMoney;
    AIMoney[j] -= ((*totalMoney)*(drand48()));
    AIMoney[j] += ((*totalMoney)*(drand48()));

    if(AIMoney[j] < (*totalMoney / 2))
    {
      AIMoney[j] = (*totalMoney / 2);
    }
  }
  // for(int k = 0; k < players; k++)
  // {
  //   printf("Computer %d: %d\n",k,AIMoney[k]);
  // }

  //printf("after deal\n");

  int cardsog = 0;
  int * cards_on_table = &cardsog;
  
  for(int i = 0; i < 3; i++)
  {
    PlayTable(OnTable, &Deck, currentCard, i);
    *cards_on_table += 1;

    int counter = 0;
    *totalBet = 0;


    do
    {
      //if folded make UserBet = -1
      *PreviousBet = *UserBet;
      PlayUser(UserBet, PreviousBet, AIBet, OnTable, UserHand, cards_on_table, totalMoney, totalBet, counter, bettingPool);

      for(int k = 0; k < players; k++)
      {
        if(Folded[k] != 1)
        {
          printf("It is Computer %d's turn to bet\n\n",k+1);
          PlayAI(k, AIHand, OnTable, UserBet, PreviousBet, totalBet, Folded, RoundCounter, *cards_on_table, bettingPool, AIBet);
        }
        else printf("Computer %d is out. Skipped.\n\n",k+1);
      }

      counter++;
      RoundCounter++;
      *bettingPool += *totalBet;

      int foldedcounter = 0;

      for(int d = 0; d < players; d++)
      {
        if(Folded[d] == 1)
        {
          foldedcounter++;
        }
      }

      if(foldedcounter == players)
      {
        break;
      }

      // printf("AIBet 1 = %d\n",AIBet[0]);
      // printf("AIBet 2 = %d\n",AIBet[1]);
      // printf("AIBet 3 = %d\n",AIBet[2]);

    } while((RoundCheck(AIBet, UserBet,players,Folded) == 1) && (counter <= 2));

    if(*UserBet < 0)
    {
      printf("Looks like you lost pal, that's tough luck... Scram.\n\n");
      return;
    }
    
  }
  //DeckValue(); to compare the remaining players cards

    int Value[4];
    Value[0] = DeckValue(OnTable, UserHand,*cards_on_table);
    Value[1] = DeckValue(OnTable, AIHand,*cards_on_table);
    if(Folded[0] == 1) Value[1] = 0;
    if(players >= 2) 
    { 
      Value[2] = DeckValue(OnTable, AIHand+2,*cards_on_table);
      if(Folded[1] == 1) Value[2] = 0;
    }
    if(players >= 3)
    {
      Value[3] = DeckValue(OnTable, AIHand+4,*cards_on_table);
      if(Folded[2] == 1) Value[3] = 0;
    }

    //Comparing Deck Values
    // int m = 0;
    // int tie[4];
    // for(int a = 0; a < (players + 1); a++)
    // {
    //   for(int b = a+1; b < (players + 1); b++)
    //   {
    //     if(Value[a] == Value[b])
    //     {
    //       m++;
    //       tie[a] = a;
    //       tie[b] = b;
    //     }
    //   }
    // }

    int whichPlayer = 0;
    for(int c = 0; c < (players); c++)
    {
      if(Value[c] > Value[c+1])
      {
        whichPlayer = c;
      }
    }

    if(whichPlayer == 0)
    {
      printf("Congratulations pal, you actually won...\n\n");
      sleep(1);
      printf("Didn't think you could do it.\n\n");
      sleep(1);
      printf("\a\a\a\a\a\a\a*cough* \n");
      sleep(BIGSLEEP);
      printf("Actually, I mean... I knew you could do it the whole time...\n\n");
      sleep(1);
      *totalMoney += *bettingPool;
      printf("Updated Funds = %d\n\n",*totalMoney);
      printf("Play another round? Y/N ");
      char answer1;
      scanf(" %c", &answer1);
      printf("\n\n");
      if((answer1 == 89) || (answer1 == 'y'))
      {
        printf("Gonna have to rig it against you after what happened to my pockets last round...\n\n");
        Piker(totalMoney);
        return;
      }
      else return;
    }
    else
    {
      printf("HAHAHAHAHAHA I KNEW YOU COULDN'T DO IT!\n\n");
      sleep(1);
      printf("Get off of my table prick...\n\n");
      sleep(1);
      printf("That is... Unless you want to funnel your Glorks into my pocket HAHAHAHAHHA\n\n");
      printf("Play another round? Y/N ");
      char answer1;
      scanf(" %c", &answer1);
      printf("\n\n");
      if((answer1 == 89) || (answer1 == 'y'))
      {
        printf("Another round it is... Hahaha you idiot.\n\n");
        Piker(totalMoney);
        return;
      }
      else 
      {
        printf("See you later fool...\n\n");
        return;
      }

    }
}

void PlayUser(int * UserBet, int * PreviousBet,int * AIBet, card * Table, card * UserHand, int *cardsOnTable, int * totalMoney, int * totalBet, int RaiseCounter, int * bettingPool)
{
  printTable(Table, cardsOnTable);
  printf("You have a ");
  printHand(UserHand, 2);
  char bet[100];
  int betValue = 0;

  while (betValue == 0)
  {
    int requirement = 1;

    if(RaiseCounter >= 1)
    {
      requirement = *totalBet - *PreviousBet;

      if(requirement < 1) requirement = 1;
    }

    do
    {
      printf("How much are you gonna bet this round?\n");
      printf("Put at least %d in or I'll kick you off my table\n\n",requirement);
      printf("Enter 0 to fold\n");
      printf("Current Money: %d Glorks\n\n",*totalMoney);
      scanf(" %s", bet);
      betValue = atoi(bet);
      if(*totalMoney < betValue)
      {
        printf("HAHAHA nice try, pal... Who do you think is paying for this?? Me?!? HHAHAHHAAHHHAA\n\n");
      }
      requirement = 0;
    }while((*totalMoney - betValue) < requirement);

    if (betValue < 1)
    {
      printf("C'mon pal, you gotta bet something...\n\n");
      betValue = 0;

      printf("Looks like you lose, pal... Knew this would happen AHAHAHA\n\n");
      printf("If you want to stay and empty your Glorks into my Shoin Bag, be my guest...\n\n");
      printf("Play another round? Y/N ");
      char answer1;
      scanf(" %c", &answer1);
      printf("\n\n");
      if((answer1 == 89) || (answer1 == 'y'))
      {
        printf("Another round it is... Hahaha you idiot.\n\n");
        Piker(totalMoney);
        return;
      }
      else 
      {
        printf("That's what I though... See you later fool.\n\n");
        return;
      }

      *totalMoney -= betValue;
      *totalBet += betValue;

    }
  }

  *UserBet = betValue;
  *bettingPool += *UserBet;
  *totalMoney -= betValue;
}

void printTable(card * Table, int * cardsOnTable)
{
  printf("On the table, there's a ");
  for (int i = 0; i < *cardsOnTable; i++)
  {
    printCard(Table[i]);
    if((*cardsOnTable >= 3) && (i != *cardsOnTable -1)) printf(", ");
    
    if ((i == *cardsOnTable - 2) && *cardsOnTable > 1)
    {
      printf(" and ");
    }
  }
  printf("\n");
}

void PlayAI(int whichAI, card * AIHand, card * Table, int * UserBet, int * PreviousBet, int * totalBet, int * folded, int roundcounter, int OnTable, int * bettingPool, int * AIBet)
{
  int value = AIMove(*PreviousBet, *UserBet, DeckValue(Table, AIHand, OnTable), roundcounter);

  if(value < 0)
  {
    folded[whichAI] = 1;
    printf("Computer %d has folded\n\n",whichAI+1);
    return;
  }
  if(value == 0)
  {
    printf("Computer %d has called\n\n",whichAI+1);
    *bettingPool += *UserBet;
    AIBet[whichAI] = *UserBet;
  }
  if(value > 0)
  {
    printf("Computer %d has raised the bet by %d\n\n",whichAI+1,value);
    *bettingPool += value;
    *totalBet += value;
    AIBet[whichAI] += value;
  }
}

void PlayTable(card * OnTable, pikerDeck * Deck, int * currentCard, int i)
{//need something to reshuffle if out of cards
  //if(*currentCard >= 40) reshuffle;
   OnTable[i] = Deck->cards[*currentCard];
  *currentCard += 1;
}

void Deal(pikerDeck * Deck, int * currentCard, card * UserHand, card * AIHand, int players)
{
  for(int i = 0; i < 2; i++)
  {
    UserHand[i] = Deck->cards[*currentCard];
    *currentCard += 1;

    for(int j = 0; j < players; j++)
    {
      AIHand[(j*2)+i] = Deck->cards[*currentCard];
      *currentCard += 1;
    }
  }
}

pikerDeck makeDeck()
{
  //static int hasBeenPlayedBefore = 0;
  static pikerDeck deck;

  const char * suits[4] = {"Bleeboes", "Gleeboes", "Schleeboes", "Fleeboes"};
  const char * values[10] = {"Ace", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Glizbo", "Schnarlack"};

  for (int i = 0; i < 40; i+=10)
  {
    for (int j = 0; j < 10; j++)
    {
      strcpy(deck.cards[i+j].suit, suits[i/10]);
      strcpy(deck.cards[i+j].valueName, values[j]);

      if (j < 10)
      {
        deck.cards[i+j].value = j+1;
      }
    }
  }

  return deck;
}

// void printCard(card cardToPrint)
// {
//   printf("%s of %s", cardToPrint.valueName, cardToPrint.suit);
// }

int initializePiker(int * totalMoney)
{
  printf("Welcome to the Piker table. Wanna play?\n");
  printf("It'll cost you 200 Glork\n");
  printf("Y/N  ");
  char answer;
  scanf(" %c", &answer);
  printf("\n\n");
  if((answer == 89) || (answer == 'y'))
  {
    if(*totalMoney < 200)
    {
      printf("Sorry, you don't have enough to play.\n\n Better luck next time...\n");  
      return 0;
    }
    else
    {
      *totalMoney -= 200; 
    }
    return 1;
  }
  else
  {
    printf("Suit yourself, pal.\n");
    printf("Stop stinking up my table then...\n\n");

    return 0;
  }
}

int DeckValue(card * Table, card * Hand, int OnTable)
{
  int tracker = 0;
  //int value = 0;

  int number = (OnTable +2);

  card deck[number];

  for(int i = 0; i < OnTable; i++)
  {
    deck[i+2] = Table[i];
  }

  for(int j = 0; j < 2; j++)
  {
    deck[j] = Hand[j];
  }

  card * sortedDeck = DeckSort(deck, number);

  int i = 0;

  //Royal Flush (10)
  if(number == 5)
  {
    tracker = 0;
    int Ace = 0;
    int Glizbo = 0;
    int Schlarnack = 0;
    int Eight = 0;
    int Seven = 0;

    for(i = 0; i < number; i++)
    {
      if(sortedDeck[i].value == 1)
      {
        Ace++; 
      }
      if(sortedDeck[i].value == 7)
      {
        Seven++;
      }
      if(sortedDeck[i].value == 8)
      {
        Eight++;
      }
      if(sortedDeck[i].value == 9)
      {
        Schlarnack++;
      }
      if(sortedDeck[i].value == 10)
      {
        Glizbo++;
      }
    }

    if((Ace == 1) && (Seven == 1) && (Eight == 1) && (Schlarnack == 1) && (Glizbo == 1))
    {
      tracker++;
    }

    if((sortedDeck[0].suit == sortedDeck[1].suit) && (tracker == 1))
    {
      return 10;
    }

  }

  tracker = 0;

  //Straight Flush (9)
  if(number == 5)
  {
    for(i = 0; i < number-1; i++)
    {
      if((sortedDeck[i].value != ((sortedDeck[i+1].value)+1)) && (strcmp(sortedDeck[i].suit, ((sortedDeck[i+1].suit)+1))))
      {
        tracker++;
      }
    }
    if(tracker == 0) return 9;
    tracker = 0;
  }

  //Four of a Kind (8)
  if(number >= 4)
  {
    int FourKind1 = sortedDeck[0].value;
    int FourKind2 = sortedDeck[1].value;

    for(i = 0; i < number; i++)
    {
      if(sortedDeck[i].value == FourKind1)
      {
        tracker++;
      }
    }
    if(tracker >= 4)
    {
      return 8;
    }
    tracker = 0;

    for(i = 0; i < number; i++)
    {
      if(sortedDeck[i].value == FourKind2)
      {
        tracker++;
      }
    }
    if(tracker >= 4)
    {
      return 8;
    }
    tracker = 0;
  }

  //Full House (7)
  if(number == 5)
  {
    int conditionthree = 0;
    int conditiontwo = 0;
    card tempcard;

    for(i = 0; i < number; i++)
    {
      for(int j = i+1; j < number; j++)
      {
        if(sortedDeck[i].value == sortedDeck[j].value)
        {
          tracker++;
        }
      }

      if(tracker == 2)
      {
        conditionthree = 1;
        tempcard = sortedDeck[i];
      }
      if((tracker == 1) && (sortedDeck[i].value != tempcard.value))
      {
        conditiontwo = 1;
      }

      tracker = 0;
    }
    if((conditionthree == 1) && (conditiontwo == 1))
    {
      return 7;
    }
    tracker = 0;

  }

  //Flush (6)
  if(number == 5)
  {
    for(i = 0; i < number-1; i++)
    {
      if(strcmp(sortedDeck[i].suit, ((sortedDeck[i+1].suit)+1)))
      {
        tracker++;
      }
    }
    if(tracker == 0) return 6;
    tracker = 0;
  }

  //Straight (5)
  if(number == 5)
  {
    for(i = 0; i < number-1; i++)
    {
      if(deck[i].value != ((deck[i+1].value)+1))
      {
        tracker++;
      }
    }
    if(tracker == 0) return 5;
    tracker = 0;
  }

  //Three of a Kind (4)
  int ThreeKind1 = sortedDeck[0].value;
  int ThreeKind2 = sortedDeck[1].value;
  int ThreeKind3 = sortedDeck[2].value;

  for(i = 0; i < number; i++)
  {
    if(sortedDeck[i].value == ThreeKind1)
    {
      tracker++;
    }
  }
  if(tracker >= 3)
  {
    return 4;
  }
  tracker = 0;

  for(i = 0; i < number; i++)
  {
    if(sortedDeck[i].value == ThreeKind2)
    {
      tracker++;
    }
  }
  if(tracker >= 3)
  {
    return 4;
  }
  tracker = 0;

  for(i = 0; i < number; i++)
  {
    if(sortedDeck[i].value == ThreeKind3)
    {
      tracker++;
    }
  }
  if(tracker >= 3)
  {
    return 4;
  }
  tracker = 0;

  //Two Pair (3)
  for(i = 0; i < number; i++)
  {
    for(int j = i+1; j < number; j++)
    {
      if(sortedDeck[i].value == sortedDeck[j].value)
      {
        tracker++;
      }
    }
  }
  if(tracker >= 2)
  {
    return 3;
  }
  tracker = 0;

  //Pair (2)
  for(i = 1; i < number; i++)
  {
    if(sortedDeck[0].value == sortedDeck[i].value)
    {
      tracker++;
    }
  }
  if(tracker >= 1) return 2;
  tracker = 0;

  //High Card (1)
    return 1;
}

card * DeckSort(card * deck, int number)
{
  card temporary;

  for (int i = 0; i < number; i++) 
  {
 
    for (int j = i + 1; j < number; j++)
    {
 
      if((deck[i].value > deck[j].value))
      {
 
        temporary = deck[i];
        deck[i] = deck[j];
        deck[j] = temporary;
 
      }
 
    }
 
  }

  return deck;

}

int RoundCheck(int * AIBet, int * UserBet, int players, int * Folded)
{
  if(Folded[0] == 1)
    {
      AIBet[0] = -1;
    }
    if(Folded[1] == 1)
    {
      AIBet[1] = -1;
    }
    if(Folded[2] == 1)
    {
      AIBet[2] = -1;
    }
  
  int tracker = 0;

  for(int i = 0; i < players; i++)
  {
    for(int j = i; j < players; j++)
    {
      if((AIBet[i] != -1) && (AIBet[j] != -1))
      {
        if(AIBet[i] != AIBet[j])
        {
          tracker++;
        }
      }
    }

  }
  return tracker;
}

void PikerRules(void)
{
  printf("=--------------------------------------=\n");
  printf("1.) As soon as the game begins you will recieve\n");
  printf("two cards in your hand. Only you can see them.\n\n");
  printf("2.) Each round a new PUBLIC card will be placed\n");
  printf("on the table. You will compare these cards to your\n");
  printf("hand to compete with other players.\n\n");
  printf("3.) Each round betting occurs. You may choose\n");
  printf("to raise your bet, call to match others' bets or\n");
  printf("fold to make no bet (you will leave the game and \n");
  printf("lose all money put into the game thus far).\n\n");
  printf("\n\n");
  printf("Types of Hands and their Rankings\n");
  printf("*********************************\n");
  printf("#1 Royal Flush = The suits are the same and your\n");
  printf("cards contain an Ace, Glizbo, Schnorlack, Eight,\n");
  printf("and Seven\n\n");
  printf("#2 Straight Flush = Five card values all in sequence\n");
  printf("and each contain the same suit.\n\n");
  printf("#3 Four of a Kind = Four cards in a row with the same\n");
  printf("value.\n\n");
  printf("#4 Full House = Three cards of one value and two cards\n");
  printf("of another value. Five cards in total.\n\n");
  printf("#5 Flush = Five cards containing the same suit.\n\n");
  printf("#6 Straight = Five cards with sequential values.\n\n");
  printf("#7 Three of a Kind = Three cards in a row with the same\n");
  printf("value, but not necessarily the same suit.\n\n");
  printf("#8 Two Pair = Your hand contains two pairs of cards each\n");
  printf("equal in value.\n\n");
  printf("#9 One Pair = Your hand contains two equivalent cards.\n\n");
  printf("#10 High Card = Nothing else in hand. If two people are\n");
  printf("competing with the 'High Card,' the person with the\n");
  printf("highest value wins\n");
  printf("=--------------------------------------=\n\n\n");
}