#include "spaceCasino.h"

int ChooseGame();

//Gets hit by bus. Alarm. Wake up in space casino

int main(void) {
  start();
  //sleep(10);

  srand(time(NULL));
  srand48(time(NULL));
  
  int totalMoney = 15000;
  int continue_game = 1;

  while(continue_game == 1)
  {
    if (totalMoney < 1)
    {
      min();
      return 0;
    }
    else if (totalMoney > 100000)
    {
      max();
      return 0;
    }
    
    int choice = 0;
    choice = ChooseGame();

    switch(choice)
    {
      case 1: 
        blackholeJack(&totalMoney);
        break;
      case 2: 
        microblazers(&totalMoney);
        break;
      case 3:
        GringleBall(&totalMoney);
        break;
      case 4:
        plutoBanco(&totalMoney);
        break;
      case 5:
        Piker(&totalMoney);
        break;
      case 6:
        leave(&totalMoney);
        break;
        
      default:
        printf("Sorry, that is not an option.\n");
        printf("Get Out.\n");
        return 0;
        break;
    }
    // printf("I hope you enjoyed your game sir! Would you like to try playing another?\n\n");
    // printf("1. Yes\n2. No\n\n");
    // scanf("%d",&continue_game);
    // printf("\n\n");

    // if(continue_game == 2) return 0;
  }

  return 0;
}

int ChooseGame()
{
  printf("What game would you like to play?\n\n");
  printf("1. Blackhole Jack\n");
  printf("2. Microblazers\n");
  printf("3. Gringle Ball\n");
  printf("4. Pluto Banco\n");
  printf("5. Piker\n");
  printf("6. Leave\n\n");

  int choice = 0;
  scanf("%d", &choice);
  printf("\n\n");

  if((choice < 1) || (choice > 6))
  {
    printf("That is not an option, please choose a different game.\n\n");
    printf("---------------------------\n\n");
    choice = ChooseGame();
  }
  return choice;
}