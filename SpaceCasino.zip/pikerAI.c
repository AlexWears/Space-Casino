#include "spaceCasino.h"

//Returns -1 if the opponent folds, 0 if they call, and a positive integer if they will raise (The integer is the amount that they raise to)
int AIMove(int previousPlayerBet, int currentPlayerBet, int AIHandQuality, int roundCounter)
{
  //Randomness
  float AIDecision = 40 + (rand() % 21);
  /*
  <50: Fold
  50-72: Call
  >75: Raise
  */

  if (roundCounter == 0)
  {
    AIDecision *= 1.4;
  }

  if (roundCounter > 0)
  {
    //Substance of Player Bet
    if ((previousPlayerBet - currentPlayerBet) > 0)
    {
      AIDecision *= 1.1;
    }
    if ((previousPlayerBet - currentPlayerBet > 0) > (previousPlayerBet+1 / 2))
    {
      AIDecision *= 1.2;
    }
    if ((previousPlayerBet - currentPlayerBet) < 0)
    {
      AIDecision *= .9;
    }
    if (currentPlayerBet > previousPlayerBet*1.25)
    {
      AIDecision *= .9;
    }
    if (currentPlayerBet > previousPlayerBet*1.5)
    {
      AIDecision *= .9;
    }
  }

  //Hand Quality
  if (AIHandQuality < 5)
  {
    AIDecision *= .9;
  }
  if (AIHandQuality < 3)
  {
    AIDecision *= .9;
  }
  if (AIHandQuality > 6)
  {
    AIDecision *= 1.15;
  }
  if (AIHandQuality > 8)
  {
    AIDecision *= 1.2;
  }
  
  //Will They Raise
  if (AIDecision > 72)
  {
    //CHECK MONEY IN PLAY FUNCTION
    float raiseAmount = 1 + (drand48()/3);
    return floor(currentPlayerBet * raiseAmount);
  }
  //Will They Fold
  if(AIDecision < 40)
  {
    return -1;
  }
  //Will They Call
  return 0;
}