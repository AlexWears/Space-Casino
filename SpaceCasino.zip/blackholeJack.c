#include "spaceCasino.h"
#define BHJ 17

void blackholeJack(int * totalMoney)
{
  if (*totalMoney < 1)
  {
    printf("Sorry, chump, but you need MONEY to gamble at my table\n");
    return;
  }

  printf("Current Account Balance: %d glork\n\n", *totalMoney);
  sleep(SMALLSLEEP);

  static blackholeJackDeck deck;

  deck = makeBlackholeJackDeck();
  printf("Welcome to Blackhole Jack! Hit or stand to try and get as close as you can to 17!\n\n\n");

  for (int j = 0; j < 2; j++)
  {
    for (int i = 0; i < 40; i++)
    {
      card cardSaver = deck.cards[i];
      int randomNumber = rand()%40;
      
      deck.cards[i] = deck.cards[randomNumber];
      deck.cards[randomNumber] = cardSaver; 
    }
  }
  
  printf("How much money do you wanna to bet, chump? ");
  int bet = getBlackholeJackBet(totalMoney);


  card dealerHand[10];
  int dealerHandSize = 2;
  int dealerAceTotal = 0;

  card playerHand[10];
  int playerHandSize = 2;
  int playerAceTotal = 0;

  int currentCard = 4;
  dealerHand[0] = deck.cards[0];
  dealerHand[1] = deck.cards[1];
  playerHand[0] = deck.cards[2];
  playerHand[1] = deck.cards[3];

  int dealerHandTotal = dealerHand[0].value + dealerHand[1].value;

  int playerHandTotal = playerHand[0].value + playerHand[1].value;

  if (strcmp(dealerHand[0].valueName, "Ace") == 0 || strcmp(dealerHand[1].valueName, "Ace") == 0)
  {
    if (strcmp(dealerHand[0].valueName, "Ace") == 0 && strcmp(dealerHand[1].valueName, "Ace") == 0)
    {
      dealerAceTotal = 2;
    }
    else
    {
      dealerAceTotal = 1;
    }
  }
  if (strcmp(playerHand[0].valueName, "Ace") == 0 || strcmp(playerHand[1].valueName, "Ace") == 0)
  {
    if (strcmp(playerHand[0].valueName, "Ace") == 0 && strcmp(playerHand[1].valueName, "Ace") == 0)
    {
      playerAceTotal = 2;
    }
    else
    {
      playerAceTotal = 1;
    }
  }

  // for (int i = 0; i < 40; i++)
  // {
  //   printf("%s of %s, value is %d\n", deck.cards[i].valueName, deck.cards[i].suit, deck.cards[i].value);
  // }

  printf("The dealer has a face-down card and a ");
  printCard(dealerHand[1]);
  printf("\n");
  printCardsArt(dealerHand, -1);
  sleep(BIGSLEEP);

  printf("You have a ");
  printCard(playerHand[0]);
  printf(" and a ");
  printCard(playerHand[1]);
  printf("\n\n");
  printCardsArt(playerHand, playerHandSize);

  int playerChoice = 0;

  /*
  0: Bust
  1: Didn't Bust, UsehandTotal for value
  2: Blackjack
  */
  int playerFinish;
  int dealerFinish = 1;

  if (playerHandTotal == BHJ)
  {
    printf("You got a Blackhole Jack!\n");
    playerFinish = 2;
    sleep(1);

    if (dealerHandTotal == BHJ)
    {
      printf("Unforunately, the dealer also got a Blackhole Jack\n");
      //printCardsArt(dealerHand, playerHandSize);
      dealerFinish = 2;
    }
    else
    {
      *totalMoney += floor(bet * 3/2)+1; //Ceiling APPARENTLY wasn't in math.h, despite the fact that I have used that before
    }

    playBlackholeJackAgain(totalMoney);
    return;
  }
  else if (dealerHandTotal == BHJ)
  {
    printf("The dealer got a Blackhole Jack\n");
    //printCardsArt(dealerHand, playerHandSize);
    dealerFinish = 2;
    *totalMoney -= bet;

    playBlackholeJackAgain(totalMoney);
    return;
  }
  
  while (playerHandTotal < BHJ && playerChoice != 2)
  {
    playerChoice = hitOrStand();
    //printf("Player total = %d\n", playerHandTotal);
    //printf("Player Choice = %d\n", playerChoice);

    if (playerChoice == 1)
    {
      playerHand[playerHandSize] = deck.cards[currentCard];
      playerHandTotal += playerHand[playerHandSize].value;
      playerHandSize++; currentCard++;

      //Start of Ace Nonsense
      if (playerHand[playerHandSize].value == 9)
      {
        playerAceTotal++;
      }
      while (playerHandTotal > BHJ && playerAceTotal > 0)
      {
        playerHandTotal -= 8;
        playerAceTotal--;
      }
      //End of Ace Nonsense

      printf("You have a ");
      printHand(playerHand, playerHandSize);
      printCardsArt(playerHand, playerHandSize);
      sleep(SMALLSLEEP);
      printf("Your total is %d\n\n", playerHandTotal);
      sleep(SMALLSLEEP);
      if (playerHandTotal >= 18)
      {
        playerFinish = 0;
        printf("You busted\n");
        sleep(SMALLSLEEP);
      }
    }
    else
    {
      playerFinish = 1;
      printf("You Stand\n");
      sleep(SMALLSLEEP);
    }
  }

  while (dealerHandTotal < 14 && playerFinish != 2 )
  {
    if (dealerHandSize == 2)
    {
      printf("The dealer flips over their face-down card, revealing the ");
      printCard(dealerHand[0]);
      printf("\n");
      //printCardsArt(dealerHand, 2);
      sleep(SMALLSLEEP);
    }

    dealerHand[dealerHandSize] = deck.cards[currentCard];
    dealerHandTotal += dealerHand[dealerHandSize].value;
    dealerHandSize++; currentCard++;
    printf("The dealer draws. They have a ");
    printHand(dealerHand, dealerHandSize);
    //printCardsArt(dealerHand, playerHandSize);
    //printf("Dealer Hand Size = %d\n", dealerHandSize);
    printf("\n");
    sleep(SMALLSLEEP);

    while (dealerHandTotal > BHJ && dealerAceTotal > 0)
    {
      dealerHandTotal -= 8;
      dealerAceTotal--;
    }
    if (dealerHandTotal > BHJ)
    {
      printf("Dealer Busts!\n");
      sleep(SMALLSLEEP);
      dealerFinish = 0;
    }
  }

  if (playerFinish == 0)
  {
    if (dealerFinish == 0)
    {
      printf("Well, both you and the dealer busted. That's a little anticlimactic for a casino game. You didn't lose any money, though, so that's good\n");
      sleep(SMALLSLEEP);
    }
    else if (dealerFinish == 1)
    {
      printf("You busted and the dealer didn't, so you lost your bet\n");
      *totalMoney -= bet;
      sleep(SMALLSLEEP);
    }
    playBlackholeJackAgain(totalMoney);
    return;
  }
  if (playerFinish == 1)
  {
    if (dealerFinish == 0)
    {
      printf("The dealer busted, so you get back twice the amount you bet!\n");
      sleep(SMALLSLEEP);
      *totalMoney += bet;
    }
    if (dealerFinish == 1)
    {
      if (playerHandTotal > dealerHandTotal)
      {
        printf("You beat the dealer!\n");
        sleep(SMALLSLEEP);
        *totalMoney += bet;
      }
      else if (playerHandTotal < dealerHandTotal)
      {
        printf("The dealer had a higher hand...\n");
        *totalMoney -= bet;
        sleep(SMALLSLEEP);
      }
    }
    playBlackholeJackAgain(totalMoney);
    return;
  }
}

//-- Start of supporter functions --
blackholeJackDeck makeBlackholeJackDeck()
{
  //static int hasBeenPlayedBefore = 0;
  static blackholeJackDeck deck;

  const char * suits[4] = {"Bleeboes", "Gleeboes", "Schleeboes", "Fleeboes"};
  const char * values[10] = {"Ace", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Glizbo", "Schnarlack"};

  for (int i = 0; i < 40; i+=10)
  {
    for (int j = 0; j < 10; j++)
    {
      strcpy(deck.cards[i+j].suit, suits[i/10]);
      strcpy(deck.cards[i+j].valueName, values[j]);

      if (j == 0)
      {
        deck.cards[i+j].value = 9;
      }
      else if (j < 8)
      {
        deck.cards[i+j].value = j+1;
      }
      else
      {
        deck.cards[i+j].value = 8;
      }
    }
  }

  return deck;
}

void printCard(card cardToPrint)
{
  printf("%s of %s", cardToPrint.valueName, cardToPrint.suit);
}
void printHand(card hand[], int handSize)
{
  for (int i = 0; i < handSize; i++)
  {
    if (i == handSize - 1)
    {
      printf("and ");
    }
    printCard(hand[i]);
    if (i != handSize-1)
    {
      printf(", ");
    }
  }
  printf(" in hand right now\n");
}

int hitOrStand(void)
{
  char scan[100];
  int scanValue = 0;

  while (scanValue != 1 && scanValue != 2)
  {
    printf("What would you like to do?\n1. Hit\n2. Stand\n");
    scanf(" %s", scan);
    scanValue = atoi(scan);

    if (scanValue == 1 || scanValue == 2)
    {
      return scanValue;
    }
  }

  return 0;
}

void playBlackholeJackAgain(int * totalMoney)
{
  printf("Do you wanna to play again? Y/N\n");

  char scan = 0;

  while (scan != 'Y' && scan != 'y' && scan != 'N' && scan != 'n')
  {
    scanf("%c", &scan);
  }
  
  if (scan == 'Y' || scan == 'y')
    blackholeJack(totalMoney);
  else
    return;
}

int getBlackholeJackBet(int * totalMoney)
{
  char scan[100];
  int scanValue = 0;

  while (scanValue == 0)
  {
    scanf("%s", scan);
    scanValue = atoi(scan);

    if (scanValue > *totalMoney)
    {
      printf("Sorry, you gotta bet an amount that you actually HAVE.\n");
      scanValue = 0;
    }
    if (scan < 0)
    {
      printf("That's... not how betting works\n");
      scanValue = 0;
    }
  }

  return scanValue;
}