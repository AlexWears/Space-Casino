#include "spaceCasino.h"

void GringleBall(int *totalMoney) {

  if (*totalMoney < 1)
  {
    printf("I'm sorry, but you don't have enough money to play Gringle Ball\n");
    return;
  }
  int choice = 0, bet = 0, number = 0, roll = 0, row = 0, amount = 0, hold = 0;;
  int glork = 0, nebo = 0, schlork = 0, blizzer = 0, porj = 0, expo = 0;
  int set1 = -1, set2 = -1;
  char evenodd[5];
  //char even[] = {'e', 'v', 'e', 'n'};
  //char odd[] = {'o', 'd', 'd'};
  char color[6];
   printf("Welcome to Gringle Ball!\n\n");
   sleep(SMALLSLEEP);
   printf("The rules of this game are simple\nThere are eight colors and 64 numbers in total. You can bet however much of your account as you want on either a color, a number, a row of numbers, a set of numbers, or even/odd numbers.\n\n Payouts:\n\tcolor - 1:1\n\tnumber - 35:1\n\trow of numbers - 10:1\n\tset of numbers - 2:1\n\teven/odd numbers - 1:1\n\n");
  sleep(MIDSLEEP);
   printf("     O   Y           I   V    \n");
   printf("     R   E   G       N   I   B \n");
   printf("     A   L   R   B   D   O   L \n");
   printf(" R   N   L   E   L   I   L   A \n");
   printf(" E   G   O   E   U   G   E   C \n");
   printf(" D   E   W   N   E   O   T   K  \n");
   printf("________________________________\n");
   for (int i = 0; i < 8; i++) {
     printf("|%o |", i);
     if (i%8 == 7) printf("\n");
   }
   for (int i = 8; i < 64; i++) {
     printf("|%o|", i);
     if (i%8 == 7) printf("\n");
   }
   
   printf("________________________________\n");
   sleep(BIGSLEEP);
   //char answer = 0;
   //printf("\nWould you like to play?  Y/N");
   //scanf("%c", &answer);
   //if (answer == 'n' || answer == 'N') return;

   printf("\n\nWould you like to bet on a number(1), set of numbers(2), even/odd(3), row of numbers(4), or a color(5)?\nEnter the number of your choice ");
   scanf("%d", &choice);
   sleep(SMALLSLEEP);
   printf("How much would you like to bet? Your current account balance is %d\n", *totalMoney);
   bet = getGringleBallBet(totalMoney);
   while (bet == 0) {
     printf("How much would you like to bet? Your current account balance is %d\n", *totalMoney);
     bet = getGringleBallBet(totalMoney);
   }
   if (bet < 0) return;
   *totalMoney -= bet;
   hold = *totalMoney;
    roll = rand()%63;
   sleep(SMALLSLEEP);
   switch(choice) {
    case 1:
      printf("What number would you like to bet on?\n");
      scanf("%d", &number);
      printRoll(roll);
      roll = toOctal(roll);
      if (number == roll) {
        printf("You Win!\n");
        moneyCount(bet*36, &glork, &nebo, &schlork, &blizzer, &porj, &expo);
        printf("%d expos, %d porji, %d blizzers, %d schlorks, %d nebos and %d glorks will be added to your account", expo, porj, blizzer, schlork, nebo, glork);
        *totalMoney += bet*36;
      }
      break;
    case 2:
      printf("What set of numbers would you like to bet on? You can bet on up to 12\nEnter your first number and last number separated by a space \n");
      scanf("%d %d", &set1, &set2);
      set1 = toDecimal(set1);
      set2 = toDecimal(set2);
      while (set2 - set1 > 12) {
        printf("Invalid set of numbers\nEnter your first number and last number separated by a space \n");
        scanf("%d %d", &set1, &set2);
        set1 = toDecimal(set1);
        set2 = toDecimal(set2);
      }
      printRoll(roll);
      if ((set1 - roll) > -1 && (roll - set2) > -1) {
        printf("You Win!\n");
        moneyCount(bet*3, &glork, &nebo, &schlork, &blizzer, &porj, &expo);
        printf("%d expos, %d porji, %d blizzers, %d schlorks, %d nebos and %d glorks will be added to your account", expo, porj, blizzer, schlork, nebo, glork);
        *totalMoney += bet*3;
      }
      break;
    case 3:
      printf("Would you like to bet on the evens or the odds?\n");
      scanf("%s", evenodd);
      printRoll(roll);
      if (strcmp(evenodd, "even") == 0 || strcmp(evenodd, "evens") == 0) {
        if (roll%2 == 0) {
          printf("You win!\n");
          moneyCount(bet*2, &glork, &nebo, &schlork, &blizzer, &porj, &expo);
          printf("%d expos, %d porji, %d blizzers, %d schlorks, %d nebos and %d glorks will be added to your account", expo, porj, blizzer, schlork, nebo, glork);
          *totalMoney += bet*2;
        }
      } else if (strcmp(evenodd, "odd") == 0 || strcmp(evenodd, "odds") == 0) {
        if (roll%2 != 0) {
          printf("You win!\n");
          moneyCount(bet*2, &glork, &nebo, &schlork, &blizzer, &porj, &expo);
          printf("%d expos, %d porji, %d blizzers, %d schlorks, %d nebos and %d glorks will be added to your account", expo, porj, blizzer, schlork, nebo, glork);
          *totalMoney += bet*2;
        }
      } else {
        printf("Inalid response\n");
      }
      break;
    case 4:
      printf("What row would you like to bet on? Rows are 1-8\n");
      scanf("%d", &row);
      while (row < 1 || row > 8) {
        printf("Invalid response\n");
        scanf("%d", &row);
      }
      while (roll - 8 >= 0) {
        amount++;
        roll -= 8;
      }
      printRoll(roll);
      if (amount + 1 == row) {
        printf("You win!");
        moneyCount(bet*11, &glork, &nebo, &schlork, &blizzer, &porj, &expo);
        printf("%d expos, %d porji, %d blizzers, %d schlorks, %d nebos and %d glorks will be added to your account", expo, porj, blizzer, schlork, nebo, glork);
        *totalMoney += bet*11;
      }
      break;
    case 5:
      printf("What color would you like?\n");
      scanf("%s", color);
      printRoll(roll);
      if (strcmp(color, "red") == 0 && roll%8 == 0) {
        printf("You win!");
        moneyCount(bet*2, &glork, &nebo, &schlork, &blizzer, &porj, &expo);
        printf("%d expos, %d porji, %d blizzers, %d schlorks, %d nebos and %d glorks will be added to your account", expo, porj, blizzer, schlork, nebo, glork);
        *totalMoney += bet*2;
      } 
      if (strcmp(color, "orange") == 0 && roll%8 == 1) {
        printf("You win!");
        moneyCount(bet*2, &glork, &nebo, &schlork, &blizzer, &porj, &expo);
        printf("%d expos, %d porji, %d blizzers, %d schlorks, %d nebos and %d glorks will be added to your account", expo, porj, blizzer, schlork, nebo, glork);
        *totalMoney += bet*2;
      }
      if (strcmp(color, "yellow") == 0 && roll%8 == 2) {
        printf("You win!");
        moneyCount(bet*2, &glork, &nebo, &schlork, &blizzer, &porj, &expo);
        printf("%d expos, %d porji, %d blizzers, %d schlorks, %d nebos and %d glorks will be added to your account", expo, porj, blizzer, schlork, nebo, glork);
        *totalMoney += bet*2;
      }
      if (strcmp(color, "green") == 0 && roll%8 == 3) {
        printf("You win!");
        moneyCount(bet*2, &glork, &nebo, &schlork, &blizzer, &porj, &expo);
        printf("%d expos, %d porji, %d blizzers, %d schlorks, %d nebos and %d glorks will be added to your account", expo, porj, blizzer, schlork, nebo, glork);
        *totalMoney += bet*2;
      }
      if (strcmp(color, "blue") == 0 && roll%8 == 4) {
        printf("You win!");
        moneyCount(bet*2, &glork, &nebo, &schlork, &blizzer, &porj, &expo);
        printf("%d expos, %d porji, %d blizzers, %d schlorks, %d nebos and %d glorks will be added to your account", expo, porj, blizzer, schlork, nebo, glork);
        *totalMoney += bet*2;
      }
      if (strcmp(color, "indigo") == 0 && roll%8 == 5) {
        printf("You win!");
        moneyCount(bet*2, &glork, &nebo, &schlork, &blizzer, &porj, &expo);
        printf("%d expos, %d porji, %d blizzers, %d schlorks, %d nebos and %d glorks will be added to your account", expo, porj, blizzer, schlork, nebo, glork);
        *totalMoney += bet*2;
      }
      if (strcmp(color, "violet") == 0 && roll%8 == 6) {
        printf("You win!");
        moneyCount(bet*2, &glork, &nebo, &schlork, &blizzer, &porj, &expo);
        printf("%d expos, %d porji, %d blizzers, %d schlorks, %d nebos and %d glorks will be added to your account", expo, porj, blizzer, schlork, nebo, glork);
        *totalMoney += bet*2;
      }
      if (strcmp(color, "black") == 0 && roll%8 == 7) {
        printf("You win!");
        moneyCount(bet*2, &glork, &nebo, &schlork, &blizzer, &porj, &expo);
        printf("%d expos, %d porji, %d blizzers, %d schlorks, %d nebos and %d glorks will be added to your account", expo, porj, blizzer, schlork, nebo, glork);
        *totalMoney += bet*2;
      }
      break;
    default:
      printf("Invalid response, please enter a number 1-5\n");
      break;
   }
   if (*totalMoney == hold) {
     //printRoll(roll);
     printf("You didn't win anything, better luck next time!\n\n");
   }
   printf("Current account balance = %d", *totalMoney);
     printf("\nWould you like to play again? Y/N ");
     char response = 0;
     scanf(" %c", &response);
     printf("\n");
     if (response == 'Y' || response == 'y') GringleBall(totalMoney);
   return;
}
void moneyCount(int total, int *glork, int *nebo, int *schlork, int *blizzer, int *porj, int *expo) {
  while (total - 1000000 >= 0) {
    total -= 1000000;
    *expo += 1;
  }
  while (total - 100000 >= 0) {
    *porj += 1;
    total -= 100000;
  }
  while (total - 10000 >= 0) {
    *blizzer += 1;
    total -= 10000;
  }
  while (total - 1000 >= 0) {
    *schlork += 1;
    total -= 1000;
  }
  while (total - 100 >= 0) {
    *nebo += 1;
    total -= 100;
  }
  while (total - 1 >= 0) {
    *glork += 1;
    total -= 1;
  }
}
void printRoll(int roll) {
  printf("Rolling . . .\n\n");
  sleep(MIDSLEEP);
  printf("Roll is %o ", roll);
      if (roll%8 == 0) printf("red ");
      if (roll%8 == 1) printf("orange ");
      if (roll%8 == 2) printf("yellow ");
      if (roll%8 == 3) printf("green ");
      if (roll%8 == 4) printf("blue ");
      if (roll%8 == 5) printf("indigo ");
      if (roll%8 == 6) printf("violet ");
      if (roll%8 == 7) printf("black ");
      printf("\n\n");
  sleep(MIDSLEEP);
}
int toOctal(int roll)
{
    int octal = 0, temp = 1;
    while (roll != 0)
    {
    	octal = octal + (roll % 8) * temp;
    	roll = roll / 8;
        temp = temp * 10;
    }
    return octal;
}
int toDecimal(int set) {
  int x = 0, result = 0, y;
  while (set > 0) {
    y = set % 8;
    set = set/10;
    result = result + y *pow(9, x);
    x++;
  }
  return result;
}
int getGringleBallBet(int *totalMoney) {
  {
  char scan[100];
  int scanValue = 0;

  while (scanValue == 0)
  {
    scanf("%s", scan);
    scanValue = atoi(scan);

    if (scanValue > *totalMoney)
    {
      printf("You do not have that much\n");
      scanValue = -1;
    } else if (scanValue < 0)
    {
      printf("No\n");
      scanValue = 0;
    } else {
      return scanValue;
    }
  }

  return scanValue;
  }
}