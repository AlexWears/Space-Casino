#include "spaceCasino.h"

void microblazers(int *moneytotal) {
  if (*moneytotal < 50) {
    printf("You have no money you useless ingrate. Get out of here\n");
    return;
  }

  static int hasBeenPlayed = 0;
  int jackpot = 0;
  double blackhole = 0.0;
  int pull = 0;
  int total = 0;
  int order = 0;
  int output[4];
  size_t slot;
  const int slots[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13};
  //const char *slots[] = {"Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune", "Pluto", "Sun", "Black Hole", "Space Jam", "Milky Way"};
  do {
    pull = 0;
    if (hasBeenPlayed == 0)
    {
      printf("Welcome to microblazers! This is a game of chance, so no skill needed. All you need to do it pay a small fee and four wheels will spin, giving you your results. If you hit two or more Black Holes you could be in troble, but hitting two or more Space Jams can lead to great rewards! You can also get payouts from getting planets in order or getting three or more of a kind. There are so many ways to win! So buckle up and let's play!\n\n");
      sleep(SMALLSLEEP);
      hasBeenPlayed++;
    }
    printf("If you would like to play microblazers it will cost you 50 glork\nType 1 and press enter\nIf you would like to exit this game type 2 and press enter\n\n");
    scanf("%d",  &pull);
    if (pull == 2) return;
  } while (pull != 1);

  *moneytotal -= 50;

  for (int i = 0; i < 4; i++) {
    slot = rand()%13;
    output[i] = slots[slot];
  }
  sleep(SMALLSLEEP);
  for (int i = 0; i < 4; i++) {
    switch(output[i]) {
      case 1:
        printf(" ~ Mercury ~");
        break;
      case 2:
        printf(" ~ Venus ~");
        break;
      case 3:
        printf(" ~ Earth ~");
        break;
      case 4:
        printf(" ~ Mars ~");
        break;
      case 5:
        printf(" ~ Jupiter ~");
        break;
      case 6:
        printf(" ~ Saturn ~");
        break;
      case 7:
        printf(" ~ Uranus ~");
        break;
      case 8:
        printf(" ~ Neptune ~");
        break;
      case 9:
        printf(" ~ Pluto ~");
        break;
      case 10:
        printf(" ~ Sun ~");
        break;
      case 11:
        printf(" ~ Black Hole ~");
        break;
      case 12:
        printf(" ~ Space Jam ~");
        break;
      case 13:
        printf(" ~ Milky Way ~");
        break;
      default:
        break;
    }
  }

  printf("\n\n");
  sleep(SMALLSLEEP);
  for (int j = 0; j < 3; j++) {
      if (output[j] == output[j+1]) total++;
      if (output[j] == 11 || output[j+1] == 11) blackhole++;
    }
  for (int k = 0; k < 4; k++) {
	    if (output[k] == 12) jackpot++;
	}
  for (int k = 0; k < 4; k++) {
    if (output[k] == (output[k] -= 1)) {
      order++;
    } else break;
  }
    if (blackhole >= 2) {
      int glork = 0, nebo = 0, schlork = 0, blizzer = 0, porj = 0, expo = 0;
      int total = (blackhole*0.25) * *moneytotal;
      moneyCount(total, &glork, &nebo, &schlork, &blizzer, &porj, &expo);
      printf("You hit black hole! %d expos, %d porji, %d blizzers, %d schlorks, %d nebos and %d glorks will be removed from your account", expo, porj, blizzer, schlork, nebo, glork);
      *moneytotal -= (blackhole*.25) * *moneytotal;
    } else if (jackpot > 1) {
      printf("Congradulations! You hit the Jackpot!\n");
      if (jackpot == 2) {
        printf("Five nebo will be added to your account\n");
        *moneytotal += 500;
      }
      if (jackpot == 3) {
        printf("Five blizzer will be added to your account\n");
        *moneytotal += 50000;
      }
      if (jackpot == 4) {
        printf("One porj will be added to your account\n");
        *moneytotal += 100000;
      }
    } else if (total > 2) {
      if (total == 3) {
        printf("You got three of a kind! One schlork will be added to your account\n");
        *moneytotal += 1000;
      }
      if (total == 4) {
        printf("You got four of a kind! One blizzer will be added to your account\n");
        *moneytotal += 10000;
      }
    } else if (order > 2) {
      if (order == 3) {
        printf("You got three in a row! One schlork will be added to your account\n");
        *moneytotal += 1000;
      }
      if (order == 4) {
        printf("You got four in a row! Five blizzers will be added to your account\n");
        *moneytotal += 50000;
      }
    } else {
      printf("Your spin did not get you anything\n");
    }
    sleep(SMALLSLEEP);
  printf("Your account balance: %d\n", *moneytotal);
  int answer = 0;
  //printf("Would you like to play again?\nY/N ");
    //scanf("%c", &answer);
  //while ((answer != 'y' || answer != 'Y' ) && (answer != 'n' && answer != 'N')) {
    //char answer = 0;
    //pull = 0;
    //printf("Invalid response, try again\n");
    printf("Would you like to play again?\n1) yes\n2) no\n ");
    scanf("%d", &answer);
  if (answer == 1) {
    microblazers(moneytotal);
  }
   if (answer == 2) return ;
}