#include "spaceCasino.h"

void plutoBanco(int * totalMoney)
{
  int check = 0;
  int glork = 0, nebo = 0, schlork = 0, blizzer = 0, porj = 0, expo = 0;
  static plutoBancoDeck deck;

  deck = makePlutoBancoDeck();

  for (int j = 0; j < 2; j++)
  {
    for (int i = 0; i < 40; i++)
    {
      card cardSaver = deck.cards[i];
      int randomNumber = rand()%40;
      
      deck.cards[i] = deck.cards[randomNumber];
      deck.cards[randomNumber] = cardSaver; 
    }
  }
  printf("Welcome to Pluto Blanco! This is a betting game where all you have to do is bet on what you think will happen. You either bet on the PLAYER, the DEALER, or you bet they will tie. Each round starts with two cards per participant, and the winner is the one with the highest score closest to nine. If neither player has a six or a seven the game continues. Whether or not more cards are drawn depends on set rules, so no worries about that! For a win on either betting on player or dealer you gete a 1:1 payout, but if you win a tie bet you get a 8:1 payout.\nNow, without further ado, lets play!\n\nYour current balance is %d\n", *totalMoney);

  int whatToBetOn; 
  /*
    0 = Player
    1 = Dealer
    2 = Tie
  */
  int bet = getPlutoBancoBet(totalMoney, &whatToBetOn); //FIX THIS
  
  card dealerHand[3];
  int dealerHandSize = 2;
  int dealerTotal;
  card playerHand[3];
  int playerHandSize = 2;
  int playerTotal;
  int currentCard = 4;
  
  dealerHand[0] = deck.cards[0];
  dealerHand[1] = deck.cards[1];
  playerHand[0] = deck.cards[2];
  playerHand[1] = deck.cards[3];

  dealerTotal = dealerHand[0].value + dealerHand[1].value;
  playerTotal = playerHand[0].value + playerHand[1].value;

  printf("The dealer has ");
  printHand(dealerHand, 2);
  printCardsArt(dealerHand, 2);
  printf("\nThe dealers total is %d", dealerTotal);
  printf("\n");
  printf("You have ");
  printHand(playerHand, playerHandSize);
  printCardsArt(playerHand, 2);
  printf("\nYour players total is %d", playerTotal);
  printf("\n");

  if (playerTotal >= 8) playerTotal -= 8;
  if (dealerTotal >= 8) dealerTotal -= 8;

  if (playerTotal >= 6 || dealerTotal >= 6)
  {
    if (playerTotal - dealerTotal == 0) {
      printf("It's a tie\n");
      if (whatToBetOn == 2) {
        printf("You win!\n");
        moneyCount(bet*9, &glork, &nebo, &schlork, &blizzer, &porj, &expo);
        printf("%d expos, %d porji, %d blizzers, %d schlorks, %d nebos and %d glorks will be added to your account\n", expo, porj, blizzer, schlork, nebo, glork);
        *totalMoney += bet*9;
      }
    } else if (playerTotal - dealerTotal  < 0) {
      printf("The dealer wins\n");
      if (whatToBetOn == 2) {
        printf("You win!\n");
        moneyCount(bet*2, &glork, &nebo, &schlork, &blizzer, &porj, &expo);
        printf("%d expos, %d porji, %d blizzers, %d schlorks, %d nebos and %d glorks will be added to your account\n", expo, porj, blizzer, schlork, nebo, glork);
        *totalMoney += bet*2;
      }
    } else {
      printf("The player wins\n");
      if (whatToBetOn == 1) {
        printf("You win!\n");
        moneyCount(bet*2, &glork, &nebo, &schlork, &blizzer, &porj, &expo);
        printf("%d expos, %d porji, %d blizzers, %d schlorks, %d nebos and %d glorks will be added to your account\n", expo, porj, blizzer, schlork, nebo, glork);
        *totalMoney += bet*2;
      }
    }
    playPlutoBancoAgain(totalMoney);
  }
  if (dealerTotal < 2) {
    dealerDraw(dealerHand, dealerTotal, deck, currentCard, dealerHandSize);
    check++;
  }
  if (playerTotal < 5 && check == 1) {
    playerHand[2] = deck.cards[currentCard];
    currentCard++;
    playerHandSize++;
    if (playerHand[2].value > 7) playerHand[2].value = 0;
    playerTotal += playerHand[2].value;
    if (playerTotal > 7) playerTotal -= 8;
    printf("The player drew a ");
    printCard(playerHand[2]);
    printCardsArt(&playerHand[2], 1);
    printf(". Their new total is %d\n", playerTotal);
  }
  if (playerTotal < 5 && check == 0) {
    playerHand[2] = deck.cards[currentCard];
    currentCard++;
    playerHandSize++;
    if (playerHand[2].value > 7) playerHand[2].value = 0;
    playerTotal += playerHand[2].value;
    if (playerTotal > 7) playerTotal -= 8;
    printf("The player drew a ");
    printCard(playerHand[2]);
    printCardsArt(&playerHand[2], 1);
    printf(". Their new total is %d\n", playerTotal);
    if (dealerTotal > 1 && dealerTotal < 5) {
      if (dealerTotal == 2) {
        if (playerHand[2].value < 5 || playerHand[2].value > 5) {
          dealerDraw(dealerHand, dealerTotal, deck, currentCard, dealerHandSize);
        }
      }
      if (dealerTotal == 3 || dealerTotal == 4) {
        if (playerHand[2].value >= 2 && playerHand[2].value <= 6) {
          dealerDraw(dealerHand, dealerTotal, deck, currentCard, dealerHandSize);
        }
      }
    }
  }
  if (playerTotal - dealerTotal == 0) {
      printf("It's a tie\n");
      if (whatToBetOn == 2) {
        printf("You win!");
        moneyCount(bet*9, &glork, &nebo, &schlork, &blizzer, &porj, &expo);
        printf("%d expos, %d porji, %d blizzers, %d schlorks, %d nebos and %d glorks will be added to your account\n", expo, porj, blizzer, schlork, nebo, glork);
        *totalMoney += bet*9;
      }
    } else if (playerTotal - dealerTotal  < 0) {
      printf("The dealer wins\n");
      if (whatToBetOn == 1) {
        printf("You win!");
        moneyCount(bet*2, &glork, &nebo, &schlork, &blizzer, &porj, &expo);
        printf("%d expos, %d porji, %d blizzers, %d schlorks, %d nebos and %d glorks will be added to your account\n", expo, porj, blizzer, schlork, nebo, glork);
        *totalMoney += bet*2;
      }
    } else {
      printf("The player wins\n");
      if (whatToBetOn == 0) {
        printf("You win!");
        moneyCount(bet*2, &glork, &nebo, &schlork, &blizzer, &porj, &expo);
        printf("%d expos, %d porji, %d blizzers, %d schlorks, %d nebos and %d glorks will be added to your account\n", expo, porj, blizzer, schlork, nebo, glork);
        *totalMoney += bet*2;
      }
    }
    playPlutoBancoAgain(totalMoney);
}

plutoBancoDeck makePlutoBancoDeck()
{
  static plutoBancoDeck deck;

  const char * suits[4] = {"Bleeboes", "Gleeboes", "Schleeboes", "Fleeboes"};
  const char * values[10] = {"Ace", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Glizbo", "Schnarlack"};

  for (int i = 0; i < 40; i+=10)
  {
    for (int j = 0; j < 10; j++)
    {
      strcpy(deck.cards[i+j].suit, suits[i/10]);
      strcpy(deck.cards[i+j].valueName, values[j]);

      if (j < 8)
      {
        deck.cards[i+j].value = j+1;
      }
      else
      {
        deck.cards[i+j].value = 0;
      }
    }
  }
  return deck;
}

void playPlutoBancoAgain(int * totalMoney)
{
  printf("Your current total is %d\n\n", *totalMoney);
  printf("Do you wanna to play again? 1) yes\n2) no\n");

  int scan = 0;

  scanf(" %d", &scan);

  while (scan != 1 && scan != 2)
  {
    scanf(" %d", &scan);
  }
  
  if (scan == 1)
    plutoBanco(totalMoney);
  else
    return; 
}

int getPlutoBancoBet(int * totalMoney, int * whatToBetOn)
{

  char bet[100];
  int betValue = 0;
  
  printf("What would you like to bet on?\n1. The Dealer\n2. The Player\n3. Tie\n");
  while (betValue == 0)
  {
    scanf(" %s", bet);
    betValue = atoi(bet);
    
    if (betValue != 1 && betValue != 2 && betValue != 3)
    {
      betValue = 0;
    }
  }
  *whatToBetOn = betValue-1;

  char scan[100];
  int scanValue = 0;
  //char trash[100];
  printf("How much do you want to bet?\n");
  while (scanValue == 0)
  {
    scanf(" %s", scan);
    scanValue = atoi(scan);

    if (scanValue > *totalMoney)
    {
      printf("Sorry, it seems that you don't have that much money.\n");
      scanValue = 0;
    }
    if (scan < 0)
    {
      printf("You must bet a positive number\n");
      scanValue = 0;
    }
  }


  return scanValue;
}
void dealerDraw(card *dealerHand, int dealerTotal, plutoBancoDeck deck, int currentCard, int dealerHandSize) {
    dealerHand[2] = deck.cards[currentCard];
    currentCard++;
    dealerHandSize++;
    if (dealerHand[2].value > 7) dealerTotal -= 8;
    dealerTotal += dealerHand[2].value;
    if (dealerTotal > 7) dealerTotal -= 8;
    printf("The dealer drew a ");
    printCard(dealerHand[2]);
    printf("\n");
    printCardsArt(&dealerHand[2], 1);
    printf(". Their new total is %d\n", dealerTotal);
}